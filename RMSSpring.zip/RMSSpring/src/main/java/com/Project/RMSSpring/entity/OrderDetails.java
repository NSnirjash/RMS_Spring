package com.Project.RMSSpring.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "orderDetails")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDetails {

    @Id
    @GeneratedValue
    private Long id;

    @Column(nullable = false)
    private double finalPrice;


    @JsonIgnore
    @OneToMany
    @JoinColumn(name = "orderId")
    private List<Order> orders;



}
