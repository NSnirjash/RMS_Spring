package com.Project.RMSSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RmsSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(RmsSpringApplication.class, args);
	}

}
