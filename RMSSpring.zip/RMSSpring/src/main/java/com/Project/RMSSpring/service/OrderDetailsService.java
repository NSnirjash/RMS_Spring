package com.Project.RMSSpring.service;

import com.Project.RMSSpring.entity.Order;
import com.Project.RMSSpring.entity.OrderDetails;
import com.Project.RMSSpring.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailsService {

    @Autowired
    private OrderRepository orderRepository;




    }


