package com.Project.RMSSpring.repository;

import com.Project.RMSSpring.entity.OrderDetails;
import org.springframework.data.repository.CrudRepository;

public interface OrderDetailsRepository extends CrudRepository<OrderDetails, Long> {
}
